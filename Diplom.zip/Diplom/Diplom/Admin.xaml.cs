﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Ad.accdb;";
        OleDbConnection myConnection;
        Settings st;
        public Admin(Settings set)
        {
            st = set;
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Пароль] FROM [Password]";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            reader.Read();
            if (reader[0].ToString() == TextBox1.Text)
            {
                myConnection.Close();
                VAdmin vad = new VAdmin(st);
                vad.Show();
                this.Close();
                st.Hide();
            }
            else
            {
                myConnection.Close();
                MessageBox.Show("Неправильный пароль");
                TextBox1.Text = "";
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }
        private void Window_Closed(object sender, EventArgs e)
        {
            st.Show();
            this.Close();
        }
    }
}
