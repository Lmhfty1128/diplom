﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для Swap.xaml
    /// </summary>
    public partial class Swap : Window
    {
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Ad.accdb;";
        OleDbConnection myConnection;
        public string name_group;
        Settings st;
        public Swap(Settings set)
        {
            st = set;
            InitializeComponent();
            get_data_fakul();
        }

        public void get_data_fakul()
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Факультеты] FROM [Fakul]";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ComboBox_Fakul.Items.Add(reader[0].ToString());
            }
            myConnection.Close();
        }

        public void get_data_otdel(string fakul)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Отделение] FROM [Otdel] WHERE [Факультеты]='" + fakul + "'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ComboBox_Otdel.Items.Add(reader[0].ToString());
            }
            myConnection.Close();
        }

        public void get_data_kurs(string fakul, string otdel)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Курс] FROM [Kurs] WHERE [Факультеты]='" + fakul + "' AND [Отделение]='" + otdel + "'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ComboBox_Kurs.Items.Add(reader[0].ToString());
            }
            myConnection.Close();
        }

        public void get_data_gryppa(string fakul, string otdel, string kurs)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Группа] FROM [Gryppa] WHERE [Факультеты]='" + fakul + "' AND [Отделение]='" + otdel + "' AND [Курс]='" + kurs + "'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ComboBox_Gryppa.Items.Add(reader[0].ToString());
            }
            myConnection.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Raspisanie aa = new Raspisanie(this, name_group);
            MessageBox.Show("Вы поменяли группу");
            this.Close();
            st.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            st.Show();
            this.Close();
        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            ComboBox_Otdel.Items.Clear();
            if (ComboBox_Fakul.SelectedItem != null)
            {
                get_data_otdel(ComboBox_Fakul.SelectedItem.ToString());
            }
        }

        private void ComboBox_SelectionChanged_2(object sender, SelectionChangedEventArgs e)
        {
            ComboBox_Kurs.Items.Clear();
            if (ComboBox_Otdel.SelectedItem != null)
            {
                get_data_kurs(ComboBox_Fakul.SelectedItem.ToString(), ComboBox_Otdel.SelectedItem.ToString());
            }
        }

        private void ComboBox_SelectionChanged_3(object sender, SelectionChangedEventArgs e)
        {
            ComboBox_Gryppa.Items.Clear();
            if (ComboBox_Kurs.SelectedItem != null)
            {
                get_data_gryppa(ComboBox_Fakul.SelectedItem.ToString(), ComboBox_Otdel.SelectedItem.ToString(), ComboBox_Kurs.SelectedItem.ToString());
            }
        }

        private void ComboBox_SelectionChanged_4(object sender, SelectionChangedEventArgs e)
        {
            if (ComboBox_Gryppa.SelectedItem != null)
            {
                name_group = ComboBox_Gryppa.SelectedItem.ToString();
                Button_perehod.IsEnabled = true;
            }
        }
    }
}
