﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для ChangeRasNext.xaml
    /// </summary>
    /// 
    class Data_Change
    {
        public Data_Change(string vremya, string poned, string vtorn, string sreda, string chetv, string pyat, string sybbota, string chetnost)
        {
            this.Время = vremya;
            this.Понедельник = poned;
            this.Вторник = vtorn;
            this.Среда = sreda;
            this.Четверг = chetv;
            this.Пятница = pyat;
            this.Суббота = sybbota;
            this.Четность = chetnost;
        }
        public string Время { get; set; }
        public string Понедельник { get; set; }
        public string Вторник { get; set; }
        public string Среда { get; set; }
        public string Четверг { get; set; }
        public string Пятница { get; set; }
        public string Суббота { get; set; }
        public string Четность { get ; set; }
    }
    public partial class ChangeRasNext : Window
    {
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Ad.accdb;";
        OleDbConnection myConnection;
        public ChangeR cr;
        public string name_group;
        public ChangeRasNext(ChangeR changer, string ng)
        {
            cr = changer;
            name_group = ng;
            InitializeComponent();
            Data_Raspis_Change();
        }
        public void Data_Raspis_Change()
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT * FROM [" + name_group + "]";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            List<Data_Change> result = new List<Data_Change>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    result.Add(new Data_Change(reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(), reader[8].ToString()));
                }
                DataGrid_Change.ItemsSource = result;
                myConnection.Close();
            }
            else
            {
                MessageBox.Show("error");
                myConnection.Close();
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            foreach (var item in DataGrid_Change.ItemsSource)
            {
                Data_Change temp = item as Data_Change;
                string query = "UPDATE [" + name_group + "] SET [Понедельник] = '"+ temp.Понедельник +"', [Вторник] = '"+ temp.Вторник + "', [Среда] = '"+ temp.Среда +"', [Четверг] = '"+ temp.Четверг + "', [Пятница] = '"+ temp.Пятница +"', [Суббота] = '"+ temp.Суббота +"' WHERE [Время]='" + temp.Время + "' AND [Четность]='" + temp.Четность +"'";
                OleDbCommand command = new OleDbCommand(query, myConnection);
                command.ExecuteNonQuery();
            }
            myConnection.Close();
        }
        private void Window_Closed(object sender, EventArgs e)
        {
            cr.Show();
            this.Close();
        }
    }
}
