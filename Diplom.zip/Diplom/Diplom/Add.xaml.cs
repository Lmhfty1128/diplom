﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для Add.xaml
    /// </summary>
    public partial class Add : Window
    {
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Ad.accdb;";
        OleDbConnection myConnection;
        VAdmin va;
        public Add(VAdmin vad)
        {
            va = vad;
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (check_fakul() && check_otdel() && check_kurs() && check_grypp())
            {
                myConnection = new OleDbConnection(connectString);
                myConnection.Open();
                string query = "INSERT INTO [Gryppa] (Факультеты, Отделение, Курс, Группа) VALUES ('" + TextBox1.Text.ToString() + "','" + TextBox2.Text.ToString() + "','" + TextBox3.Text.ToString() + "','" + TextBox4.Text.ToString() + "')";             
                OleDbCommand command = new OleDbCommand(query, myConnection);
                command.ExecuteNonQuery();
                myConnection.Close();
                create_table(TextBox4.Text.ToString());
                MessageBox.Show("Группа добавлена");
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
            }
            //MainWindow newWindow = new MainWindow();
            //Application.Current.MainWindow = newWindow;
        }

        private void create_table(string gryppa_name)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = myConnection;
            command.CommandText = "CREATE TABLE [" + gryppa_name + "] ([Код] AUTOINCREMENT PRIMARY KEY, [Время] text, [Понедельник] text, [Вторник] text, [Среда] text, [Четверг] text, [Пятница] text, [Суббота] text, [Четность] text)";
            command.ExecuteNonQuery();
            command.Connection.Close();
            myConnection.Close();
            vremya(gryppa_name);
        }

        private void vremya(string gryppa_name)
        {
            string[] arr_time = { "8:30-10:00", "10:15-11:45", "12:00-13:30", "14:00-15:30", "15:45-17:15", "8:30-10:00", "10:15-11:45", "12:00-13:30", "14:00-15:30", "15:45-17:15" };
            string[] arr_chet = { "1", "1", "1", "1", "1", "2", "2", "2", "2", "2" };
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            for (int i = 0; i < 10; i++)
            {
                string query = "INSERT INTO [" + gryppa_name + "] (Время, Четность) VALUES ('" + arr_time[i] +"','" + arr_chet[i] +"')";
                OleDbCommand command = new OleDbCommand(query, myConnection);
                command.ExecuteNonQuery();
            }
            myConnection.Close();
        }
        private bool check_fakul()
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Факультеты] FROM [Fakul] WHERE [Факультеты] = '" + TextBox1.Text + "'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                myConnection.Close();
                return true;
            }
            else
            {
                MessageBox.Show("Такого факультета нету");
                TextBox1.Text = "";
                return false;
            }
        }

        private bool check_otdel()
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Отделение] FROM [Otdel] WHERE [Отделение] = '" + TextBox2.Text + "'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                myConnection.Close();
                return true;
            }
            else
            {
                MessageBox.Show("Такого отделение нету");
                TextBox2.Text = "";
                return false;
            }
        }

        private bool check_kurs()
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Курс] FROM [Kurs] WHERE [Курс] = '" + TextBox3.Text + "'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                myConnection.Close();
                return true;
            }
            else
            {
                MessageBox.Show("Такого курса нету");
                TextBox3.Text = "";
                return false;
            }
        }

        private bool check_grypp()
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Группа] FROM [Gryppa] WHERE [Группа] = '" + TextBox4.Text + "'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                MessageBox.Show("Такая группа уже есть");
                TextBox4.Text = "";
                return false;
            }
            else
            {
                myConnection.Close();
                return true;
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            va.Show();
            this.Close();
        }
    }
}
