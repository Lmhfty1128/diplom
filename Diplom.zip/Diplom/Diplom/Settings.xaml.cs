﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для Settings.xaml
    /// </summary>
    public partial class Settings : Window
    {
        public Raspisanie rs;
        public Settings(Raspisanie mw2)
        {
            rs = mw2;
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Swap sw = new Swap(this);
            //sw.Show();
            //this.Hide();
            rs.mw.Show();
            this.Close();
            rs.Hide();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Change ch = new Change(this);
            ch.Show();
            this.Hide();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Admin ad = new Admin(this);
            ad.Show();
            this.Hide();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            rs.Show();
            this.Close();
        }
    }
}
