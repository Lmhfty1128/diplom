﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для GeneretionRaspis.xaml
    /// </summary>
    public partial class GeneretionRaspis : Window
    {
        VAdmin va;
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Ad.accdb;";
        OleDbConnection myConnection;
        public GeneretionRaspis(VAdmin va1)
        {
            va = va1;
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int Chasi_i = int.Parse(Chasi.Text);
            int Nedel_i = int.Parse(Nedel_V_Semestre.Text);
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT [Предмет] FROM [Prepod]";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            reader.Read();
            if (reader[0].ToString() == Predmet.Text)
            {
                if (Chasi_i % 10 == 0)
                {
                    int Skok_Par = Chasi_i * 60 / 90;
                    string query1 = "SELECT [Группа] FROM [Gryppa]";
                    OleDbCommand command1 = new OleDbCommand(query1, myConnection);
                    OleDbDataReader reader1 = command1.ExecuteReader();
                    reader1.Read();
                    if (reader1.HasRows)
                    {

                    }
                    else
                    {
                        MessageBox.Show("Такой группы нет");
                        Gryppa.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Неправильный ввод часов предмета в семетре");
                    Chasi.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Нет такого предмета");
                Predmet.Text = "";
            }
            myConnection.Close();
        }
    }
}
