﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.IO.Packaging;
using System.Linq;
using System.Reflection;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для Raspisanie.xaml
    /// </summary>
    class Data_Raspis
    {
        public Data_Raspis(string vremya, string poned, string vtorn, string sreda, string chetv, string pyat, string sybbota)
        {
            this.Время = vremya;
            this.Понедельник = poned;
            this.Вторник = vtorn;
            this.Среда = sreda;
            this.Четверг = chetv;
            this.Пятница = pyat;
            this.Суббота = sybbota;
        }
        public string Время { get; set; }
        public string Понедельник { get; set; }
        public string Вторник { get; set; }
        public string Среда { get; set; }
        public string Четверг { get; set; }
        public string Пятница { get; set; }
        public string Суббота { get; set; }
    }
    public partial class Raspisanie : Window
    {
        public MainWindow mw;
        public Swap sw;
        public string name_group;
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Ad.accdb;";
        OleDbConnection myConnection;
        public Raspisanie(MainWindow mw1, string ng)
        {
            mw = mw1;
            name_group = ng;
            InitializeComponent();
            Is_check_chet();
            Chet();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Settings wm = new Settings(this);
            wm.Show();
            this.Hide();
        }

        public void Is_check_chet()
        {
            if (Chetnost.Content.ToString() == "Четная")
            {
                Data_Raspis_Load("1");
            }
            else
            {
                Data_Raspis_Load("2");
            }
        }

        public void Chet()
        {
            string[] subs = DateTime.Today.ToString().Split(' ');
            string[] date_subs = subs[0].Split('.');
            string db_day = select_chet("День");
            int i_db_day = int.Parse(db_day);
            int to_day = int.Parse(date_subs[0]);
            if (to_day - i_db_day == 7 || to_day - i_db_day == -24 || to_day - i_db_day == -23 || to_day - i_db_day == -21)
            {
                if (select_chet("Четность") == "Четная")
                {
                    update_chet(to_day, "Нечетная");
                }
                else
                {
                    update_chet(to_day, "Четная");
                }
                Chetnost.Content = select_chet("Четность");
            }
            else if (to_day - i_db_day < 7)
            {
                Chetnost.Content = select_chet("Четность");
            }
        }

        public void update_chet(int day, string ch)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "UPDATE [Четность] SET [День] = " + day + ", [Четность] ='" + ch +"'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            command.ExecuteNonQuery();
            myConnection.Close();
        }

        public string select_chet(string squery)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT ["+ squery +"] FROM [Четность]";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            reader.Read();
            string tool = reader[0].ToString();
            myConnection.Close();
            return tool;
        }

        public void Data_Raspis_Load(string ch)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string query = "SELECT * FROM ["+ name_group +"] WHERE [Четность] = '"+ ch +"'";
            OleDbCommand command = new OleDbCommand(query, myConnection);
            OleDbDataReader reader = command.ExecuteReader();
            List<Data_Raspis> result = new List<Data_Raspis>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    result.Add(new Data_Raspis(reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString()));
                }
                DataGrid_Raspis.ItemsSource = result;
                myConnection.Close();
            }
            else
            {
                MessageBox.Show("error");
                myConnection.Close();
            }
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
